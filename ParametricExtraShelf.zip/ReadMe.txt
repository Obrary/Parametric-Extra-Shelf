Product: Parametric Extra Shelf, September 2014

Designer: Jens Dyvik, http://www.dyvikdesign.com/

Support:  http://forums.obrary.com/category/designs/parametric-extra-shelf

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Parametric Extra Shelf is cut on a laser cutter.  It can be made from acrylic, plywood or MDF.